# Empresa Fictícia A
Este site foi gerado pelo **Site Express Studio Pro**.
O HTML pode ser hospedado em provedores estáticos, mas fontes, Tailwind CDN, imagens remotas e eventuais rotas /api dependem de conectividade e da configuração do backend:
- Vercel: basta arrastar esta pasta
- Netlify / Cloudflare Pages / GitHub Pages
- Servidor cPanel, Nginx ou Apache

## Arquivos:
- index.html: Código completo do site com estilos embutidos e scripts de conversão.
- site-manifest.json: Informações e configurações do projeto.
